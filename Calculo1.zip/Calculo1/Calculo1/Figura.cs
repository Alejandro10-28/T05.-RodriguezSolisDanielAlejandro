﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Calculo1
{
    class Figura
    {
        //Encapsulamiento de las variables
        public string Nombre { get; set; }
        public double ladoA { get; set; }
        public double laboB { get; set; }

    }
}
